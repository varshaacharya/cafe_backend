const router =require("express").Router();

const registerRouter=require("../Products/product.router");
const employeeRouter=require("../Employee/employee.router");
const userRegisterRouter=require("../Userregister/userregister.router");
const authRouter=require("../Auth/auth.router");

// const {verifyToken}=require("../Auth/auth.controller");

router.use("/api/register",registerRouter);
router.use("/api/employee",employeeRouter);
router.use("/api/userRegister",userRegisterRouter);
router.use("/api/auth",authRouter);

module.exports=router;